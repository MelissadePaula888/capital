## 📌 Como acessar e trabalhar no projeto pelo GitHub

Cada integrante deverá seguir estes passos:

### 1. Instalar o Git
Baixe e instale o Git no computador:
https://git-scm.com/downloads

### 2. Aceitar o convite
Acesse seu GitHub e aceite o convite enviado pelo administrador do repositório.

### 3. Baixar o projeto
Escolha uma pasta no computador onde deseja guardar o projeto.

Abra o terminal nessa pasta e execute:

```bash
git clone https://github.com/benjaminmandla-lx/NapnApp.git
```

### 4. Abrir o projeto
Entre na pasta que foi criada pelo comando `git clone` usando cd e abra o projeto no VS Code ou editor de sua preferência.

### 5. Antes de começar a trabalhar
Sempre execute:

```bash
git pull origin main
```

Isso atualiza seu projeto com as alterações enviadas pelos outros integrantes.

### 6. Depois de terminar suas alterações
Execute os comandos:

```bash
git add .
git commit -m "Descrição do que foi alterado"
git push origin main
```

### ⚠️ Algumas regras importantes

- Sempre execute `git pull origin main` antes de começar a trabalhar.
- Não altere arquivos que outro integrante esteja modificando ao mesmo tempo.
- Não apague arquivos sem avisar o grupo.
- Sempre faça commit com uma descrição do que foi feito.
- Avise o grupo quando enviar suas alterações.

**Pronto!** Assim, todos poderão trabalhar no mesmo projeto e compartilhar as atualizações pelo GitHub.
