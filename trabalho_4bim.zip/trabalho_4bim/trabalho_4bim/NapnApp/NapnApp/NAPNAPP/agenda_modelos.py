
from datetime import datetime

from NAPNAPP import db


class Compromisso(db.Model):

    __tablename__ = 'compromissos'

    id = db.Column(db.Integer, primary_key=True)

    titulo = db.Column(db.String(120), nullable=False)
    descricao = db.Column(db.Text, nullable=True)

    aluno = db.Column(db.String(100), nullable=False)
    monitor = db.Column(db.String(100), nullable=False)

    data = db.Column(db.Date, nullable=False)

    horario_inicio = db.Column(db.Time, nullable=False)
    horario_fim = db.Column(db.Time, nullable=False)

    status = db.Column(db.String(20), default='Agendado')

    presenca_aluno = db.Column(
        db.String(20), default='Pendente'
    )

    presenca_monitor = db.Column(
        db.String(20), default='Pendente'
    )

    arquivado = db.Column(db.Boolean, default=False)

    criado_em = db.Column(
        db.DateTime, default=datetime.utcnow
    )
