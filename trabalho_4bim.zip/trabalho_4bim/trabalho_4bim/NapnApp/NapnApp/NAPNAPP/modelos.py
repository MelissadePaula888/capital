from datetime import datetime

from NAPNAPP import db,bcrypt


# ============================================================
# USUARIO
# ============================================================

class Usuario(db.Model):
    __tablename__ = 'usuarios'

    id = db.Column(db.Integer,primary_key=True)
    nome = db.Column(db.String(100),nullable=False)
    email = db.Column(db.String(120),unique=True,nullable=False)
    senha = db.Column(db.String(255),nullable=False)
    data_nascimento = db.Column(db.Date,nullable=True)
    tipo = db.Column(db.String(20),nullable=False)
    prontuario = db.Column(db.String(30),unique=True,nullable=True)
    foto = db.Column(db.String(200),nullable=True)

    @property
    def senha_criptografada(self):
        return self.senha_criptografada
    
    @senha_criptografada.setter
    def senha_criptografada(self, senha_texto):
        self.senha = bcrypt.generate_password_hash(senha_texto).decode('utf-8')

    def verificar_senha(self, senha_texto):
        return bcrypt.check_password_hash(self.senha, senha_texto)

# ============================================================
# LAUDO (planilha de laudos, exames e demais documentos do NAPNE)
# Cada linha é um documento ligado a um aluno.
# ============================================================

class Laudo(db.Model):
    __tablename__ = 'laudos'

    id = db.Column(db.Integer, primary_key=True)

    # Aluno
    aluno_nome = db.Column(db.String(100), nullable=False)
    aluno_prontuario = db.Column(db.String(30), nullable=False)
    curso_turma = db.Column(db.String(100), nullable=True)

    # Documento
    tipo_documento = db.Column(db.String(50), nullable=False)
    condicao = db.Column(db.String(200), nullable=True)   # CID / necessidade específica
    data_documento = db.Column(db.Date, nullable=True)
    profissional = db.Column(db.String(150), nullable=True)  # médico, clínica, escola...
    observacoes = db.Column(db.Text, nullable=True)

    # Arquivo anexado (PDF, imagem...)
    arquivo_nome = db.Column(db.String(255), nullable=True)   # nome original
    arquivo_salvo = db.Column(db.String(255), nullable=True)  # nome guardado no servidor

    # Controle
    criado_em = db.Column(db.DateTime, default=datetime.now)
    criado_por = db.Column(db.String(100), nullable=True)

# ============================================================
# ALUNOS
# ============================================================

class Aluno(db.Model):
    __tablename__ = 'alunos'

    id = db.Column(db.Integer, primary_key=True)

    nome = db.Column(db.String(120), nullable=False)

    turma = db.Column(db.String(80), nullable=False)

    foto = db.Column(db.String(255), nullable=True)

    data_nascimento = db.Column(db.Date, nullable=True)

    # Identificação e contatos do aluno
    prontuario = db.Column(db.String(30), nullable=True)
    identidade = db.Column(db.String(30), nullable=True)  # RG ou CPF
    email_institucional = db.Column(db.String(120), nullable=True)
    contato_responsaveis = db.Column(db.String(255), nullable=True)

    dados_adicionais = db.Column(db.Text, nullable=True)

    criado_em = db.Column(
        db.DateTime,
        default=datetime.now
    )

class ArquivoAluno(db.Model):
    __tablename__ = 'arquivos_alunos'

    id = db.Column(db.Integer, primary_key=True)

    aluno_id = db.Column(
        db.Integer,
        db.ForeignKey('alunos.id'),
        nullable=False
    )

    nome_original = db.Column(
        db.String(255),
        nullable=False
    )

    nome_arquivo = db.Column(
        db.String(255),
        nullable=False
    )

    criado_em = db.Column(
        db.DateTime,
        default=datetime.now
    )