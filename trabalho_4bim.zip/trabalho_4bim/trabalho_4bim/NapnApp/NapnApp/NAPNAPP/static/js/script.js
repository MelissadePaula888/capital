// Função para abrir e fechar a barra lateral
function toggleSidebar() {
    const sidebar = document.getElementById('minha-sidebar');
    if (sidebar) sidebar.classList.toggle('recolhida');
}

// ============================================================
// Planilha de laudos: janela de cadastro / edição
// ============================================================
document.addEventListener('DOMContentLoaded', function () {
    const modalEl = document.getElementById('modal-laudo');
    if (!modalEl) return;

    if (typeof bootstrap === 'undefined') return;
    const modal = new bootstrap.Modal(modalEl);
    const form = document.getElementById('form-laudo');
    const titulo = document.getElementById('modal-laudo-titulo');
    const aviso = document.getElementById('aviso-arquivo-atual');

    // Botão "Novo registro": formulário limpo
    const btnNovo = document.getElementById('btn-novo-laudo');
    if (btnNovo) btnNovo.addEventListener('click', function () {
        form.reset();
        form.action = form.dataset.actionNovo;
        titulo.textContent = 'Novo registro';
        aviso.classList.add('d-none');
        modal.show();
    });

    // Botões de lápis: formulário preenchido com a linha escolhida
    document.querySelectorAll('.btn-editar-laudo').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const d = btn.dataset;
            form.reset();
            form.action = d.action;
            titulo.textContent = 'Editar registro';

            form.aluno_nome.value = d.alunoNome;
            form.aluno_prontuario.value = d.alunoProntuario;
            form.curso_turma.value = d.cursoTurma;
            form.tipo_documento.value = d.tipoDocumento;
            form.condicao.value = d.condicao;
            form.data_documento.value = d.dataDocumento;
            form.profissional.value = d.profissional;
            form.observacoes.value = d.observacoes;

            if (d.arquivo) {
                aviso.textContent = 'Arquivo atual: ' + d.arquivo + ' (envie outro só se quiser substituir)';
                aviso.classList.remove('d-none');
            } else {
                aviso.classList.add('d-none');
            }
            modal.show();
        });
    });
});
