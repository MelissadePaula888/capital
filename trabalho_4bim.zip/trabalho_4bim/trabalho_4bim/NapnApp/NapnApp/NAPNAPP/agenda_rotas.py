
import calendar
from datetime import datetime, date, timedelta

from flask import render_template, request, redirect, url_for, flash

from NAPNAPP import app, db
from NAPNAPP.agenda_modelos import Compromisso
from NAPNAPP.rotas import login_required


# ============================================================
# LISTAR COMPROMISSOS
# ============================================================


@app.route("/agenda")
@login_required
def agenda():

    hoje = date.today()

    mes = request.args.get("mes", hoje.month, type=int)
    ano = request.args.get("ano", hoje.year, type=int)
    dia = request.args.get("dia", type=int)

    # Valida o mês e o ano
    if mes < 1 or mes > 12 or ano < 1900 or ano > 2100:
        mes = hoje.month
        ano = hoje.year

    # Consulta os compromissos ativos
    todos_compromissos = Compromisso.query.filter_by(
        arquivado=False
    ).order_by(
        Compromisso.data,
        Compromisso.horario_inicio
    ).all()

    # Compromissos do mês selecionado
    compromissos_mes = [
        c for c in todos_compromissos
        if c.data.month == mes and c.data.year == ano
    ]

    # Conta os compromissos de cada dia
    contagem_dias = {}

    for compromisso in compromissos_mes:
        numero_dia = compromisso.data.day

        contagem_dias[numero_dia] = (
            contagem_dias.get(numero_dia, 0) + 1
        )

    # Monta o calendário começando no domingo
    calendario_mes = calendar.Calendar(
        firstweekday=6
    ).monthdayscalendar(ano, mes)

    # Navegação entre meses
    primeiro_dia = date(ano, mes, 1)

    mes_anterior = primeiro_dia - timedelta(days=1)
    proximo_mes = (
        primeiro_dia.replace(day=28) + timedelta(days=4)
    ).replace(day=1)

    # Filtra os compromissos da lista pelo dia escolhido
    compromissos_lista = compromissos_mes

    if dia and 1 <= dia <= calendar.monthrange(ano, mes)[1]:
        compromissos_lista = [
            c for c in compromissos_mes
            if c.data.day == dia
        ]
    else:
        dia = None

    return render_template(
    "agenda.html",
    compromissos=compromissos_lista,
    compromissos_mes=compromissos_mes,
    calendario_mes=calendario_mes,
    contagem_dias=contagem_dias,
    mes=mes,
    ano=ano,
    dia_selecionado=dia,
    mes_anterior=mes_anterior,
    proximo_mes=proximo_mes,
    mostrar_arquivados=False,
    nome_mes=[
        "janeiro", "fevereiro", "março",
        "abril", "maio", "junho",
        "julho", "agosto", "setembro",
        "outubro", "novembro", "dezembro"
    ][mes - 1]
)



# ============================================================
# LISTAR COMPROMISSOS ARQUIVADOS
# ============================================================

@app.route("/agenda/arquivados")
@login_required
def agenda_arquivados():

    compromissos = Compromisso.query.filter_by(
        arquivado=True
    ).order_by(
        Compromisso.data.desc()
    ).all()

    return render_template(
        "agenda.html",
        compromissos=compromissos,
        mostrar_arquivados=True
    )


# ============================================================
# FUNÇÃO PARA SALVAR OS DADOS DO FORMULÁRIO
# ============================================================

def preencher_compromisso(compromisso):

    titulo = request.form.get("titulo", "").strip()
    descricao = request.form.get("descricao", "").strip()
    aluno = request.form.get("aluno", "").strip()
    monitor = request.form.get("monitor", "").strip()

    data = request.form.get("data", "")
    inicio = request.form.get("horario_inicio", "")
    fim = request.form.get("horario_fim", "")

    if not all([titulo, aluno, monitor, data, inicio, fim]):
        flash("Preencha todos os campos obrigatórios.", "warning")
        return False

    try:
        data_convertida = datetime.strptime(
            data, "%Y-%m-%d"
        ).date()

        inicio_convertido = datetime.strptime(
            inicio, "%H:%M"
        ).time()

        fim_convertido = datetime.strptime(
            fim, "%H:%M"
        ).time()

    except ValueError:
        flash("Data ou horário inválido.", "danger")
        return False

    if fim_convertido <= inicio_convertido:
        flash("O horário final deve ser posterior ao inicial.", "warning")
        return False

    compromisso.titulo = titulo
    compromisso.descricao = descricao
    compromisso.aluno = aluno
    compromisso.monitor = monitor
    compromisso.data = data_convertida
    compromisso.horario_inicio = inicio_convertido
    compromisso.horario_fim = fim_convertido

    return True


# ============================================================
# CRIAR COMPROMISSO
# ============================================================

@app.route("/agenda/novo", methods=["GET", "POST"])
@login_required
def criar_compromisso():

    compromisso = Compromisso()

    if request.method == "POST":

        if preencher_compromisso(compromisso):

            db.session.add(compromisso)
            db.session.commit()

            flash("Compromisso cadastrado com sucesso!", "success")

            return redirect(url_for("agenda"))

    return render_template(
        "agenda_form.html",
        compromisso=compromisso,
        titulo_pagina="Novo compromisso"
    )


# ============================================================
# EDITAR COMPROMISSO
# ============================================================

@app.route("/agenda/editar/<int:id>", methods=["GET", "POST"])
@login_required
def editar_compromisso(id):

    compromisso = Compromisso.query.get_or_404(id)

    if compromisso.arquivado:
        flash("Não é possível editar um compromisso arquivado.", "warning")
        return redirect(url_for("agenda_arquivados"))

    if request.method == "POST":

        if preencher_compromisso(compromisso):

            db.session.commit()

            flash("Compromisso atualizado com sucesso!", "success")

            return redirect(url_for("agenda"))

    return render_template(
        "agenda_form.html",
        compromisso=compromisso,
        titulo_pagina="Editar compromisso"
    )


# ============================================================
# EXCLUIR COMPROMISSO
# ============================================================

@app.route("/agenda/excluir/<int:id>", methods=["POST"])
@login_required
def excluir_compromisso(id):

    compromisso = Compromisso.query.get_or_404(id)

    db.session.delete(compromisso)
    db.session.commit()

    flash("Compromisso excluído com sucesso.", "success")

    return redirect(
        url_for("agenda_arquivados")
        if compromisso.arquivado
        else url_for("agenda")
    )


# ============================================================
# ARQUIVAR / RESTAURAR COMPROMISSO
# ============================================================

@app.route("/agenda/arquivar/<int:id>", methods=["POST"])
@login_required
def arquivar_compromisso(id):

    compromisso = Compromisso.query.get_or_404(id)

    compromisso.arquivado = not compromisso.arquivado

    db.session.commit()

    if compromisso.arquivado:
        flash("Compromisso arquivado.", "success")
        return redirect(url_for("agenda"))

    flash("Compromisso restaurado.", "success")
    return redirect(url_for("agenda_arquivados"))


# ============================================================
# REGISTRAR PRESENÇAS
# ============================================================

@app.route("/agenda/presenca/<int:id>", methods=["POST"])
@login_required
def registrar_presenca(id):

    compromisso = Compromisso.query.get_or_404(id)

    if compromisso.arquivado:
        flash("Não é possível alterar um compromisso arquivado.", "warning")
        return redirect(url_for("agenda_arquivados"))

    presenca_aluno = request.form.get("presenca_aluno")
    presenca_monitor = request.form.get("presenca_monitor")

    opcoes = ["Pendente", "Presente", "Faltou"]

    if presenca_aluno not in opcoes or presenca_monitor not in opcoes:
        flash("Opção de presença inválida.", "danger")
        return redirect(url_for("agenda"))

    compromisso.presenca_aluno = presenca_aluno
    compromisso.presenca_monitor = presenca_monitor

    if (
    presenca_aluno != "Pendente"
    and presenca_monitor != "Pendente"
    ):
        compromisso.status = "Concluído"
    else:
        compromisso.status = "Agendado"

    db.session.commit()

    flash("Presenças atualizadas!", "success")

    return redirect(url_for("agenda"))
