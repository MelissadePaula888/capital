import os

from flask_bcrypt import Bcrypt
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
bcrypt = Bcrypt(app)

app.config['UPLOAD_FOLDER'] = 'NAPNAPP/static/uploads'
app.config['ALUNOS_UPLOAD_FOLDER'] = os.path.join(
    app.root_path, 'static', 'uploads', 'alunos'
)

# Arquivos de laudos ficam fora de /static e são entregues apenas pela rota protegida.
app.config['LAUDOS_FOLDER'] = os.path.join(app.instance_path, 'laudos_arquivos')
os.makedirs(app.config['LAUDOS_FOLDER'], exist_ok=True)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.secret_key = 'chave_secreta'
app.permanent_session_lifetime = 3600

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///napnapp.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

usuarios = []
# Importa os modelos para registrar as tabelas
from NAPNAPP.modelos import *
from NAPNAPP.agenda_modelos import *

# Importa as rotas
from NAPNAPP import rotas
from NAPNAPP import agenda_rotas

# Cria as tabelas caso ainda não existam
with app.app_context():
    db.create_all()
    # Adiciona os novos campos à tabela existente sem apagar registros.
    if db.engine.dialect.name == "sqlite":
        from sqlalchemy import inspect

        colunas_alunos = {
            coluna["name"]
            for coluna in inspect(db.engine).get_columns("alunos")
        }

        novas_colunas = {
            "prontuario": "VARCHAR(30)",
            "identidade": "VARCHAR(30)",
            "email_institucional": "VARCHAR(120)",
            "contato_responsaveis": "VARCHAR(255)",
        }

        with db.engine.begin() as conexao:
            for nome_coluna, tipo_coluna in novas_colunas.items():
                if nome_coluna not in colunas_alunos:
                    conexao.exec_driver_sql(
                        f"ALTER TABLE alunos ADD COLUMN {nome_coluna} {tipo_coluna}"
                    )