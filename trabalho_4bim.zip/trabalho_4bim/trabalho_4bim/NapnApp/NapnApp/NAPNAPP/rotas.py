
import os
import secrets
import uuid
from datetime import date, datetime

from functools import wraps

from flask import (render_template,request,redirect,url_for,session, flash, abort, send_from_directory)
from sqlalchemy import or_
from werkzeug.exceptions import RequestEntityTooLarge
from werkzeug.utils import secure_filename

from NAPNAPP import app, db
from NAPNAPP.modelos import (
    Usuario,
    Laudo,
    Aluno,
    ArquivoAluno
)


# ============================================================
# DECORADOR PARA PROTEGER ROTAS
# ============================================================

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'usuario' not in session:
            return redirect(url_for('login'))

        return f(*args, **kwargs)

    return decorated_function


# ============================================================
# DASHBOARD
# ============================================================

@app.route("/")
@login_required
def home():
    return render_template("dashboard.html")


# ============================================================
# LOGIN
# ============================================================

@app.route("/login")
def login():

    # Cria o administrador automaticamente caso não exista
        administrador = Usuario.query.filter_by(tipo="ADM").first()
    
        if administrador is None:
    
            administrador = Usuario(
                nome="Administrador",
                email="admin@admin.com",
                senha="admin123",
                data_nascimento=date(2000, 1, 1),
                tipo="ADM",
                prontuario="ADMIN",
                foto=None
            )
    
            db.session.add(administrador)
            db.session.commit()
    
        return render_template(
            "login.html",
            resultado=None
        )
        
@app.route("/logout")
def logout():

    session.clear()

    return redirect(url_for("login"))


# ============================================================
# AUTENTICAÇÃO
# ============================================================

@app.route("/autenticar", methods=["POST"])
def autenticar():

    prontuario = request.form.get("prontuario")
    senha = request.form.get("senha")

    usuario = Usuario.query.filter_by(
        prontuario=prontuario,
        senha=senha
    ).first()

    if usuario:

        session.permanent = True

        session["usuario_tipo"] = usuario.tipo
        session["usuario_id"] = usuario.id
        session["usuario"] = usuario.prontuario
        session["nome_usuario"] = usuario.nome

        return redirect(url_for("home"))

    return render_template(
        "login.html",
        resultado="falha"
    )

# ============================================================
# NOSSOS ALUNOS
# ============================================================

EXTENSOES_FOTO_ALUNO = {"png", "jpg", "jpeg", "webp"}


@app.route("/nossos-alunos")
@login_required
def nossos_alunos():

    alunos = Aluno.query.order_by(Aluno.nome.asc()).all()

    return render_template(
        "nossos_alunos.html",
        alunos=alunos
    )


@app.route("/nossos-alunos/adicionar", methods=["POST"])
@login_required
def adicionar_aluno():

    if not token_valido():
        abort(400)

    nome = request.form.get("nome", "").strip()
    turma = request.form.get("turma", "").strip()
    foto = request.files.get("foto")

    nome_foto = None

    if not nome or not turma:
        flash("Preencha o nome e a turma do aluno.", "danger")
        return redirect(url_for("nossos_alunos"))

    if len(nome) > 120 or len(turma) > 80:
        flash("Nome ou turma muito grande.", "danger")
        return redirect(url_for("nossos_alunos"))

    if foto and foto.filename:

        nome_seguro = secure_filename(foto.filename)

        extensao = (
            nome_seguro.rsplit(".", 1)[-1].lower()
            if "." in nome_seguro else ""
        )

        if extensao not in EXTENSOES_FOTO_ALUNO:
            flash("Formato de foto inválido.", "danger")
            return redirect(url_for("nossos_alunos"))

        os.makedirs(
            app.config["ALUNOS_UPLOAD_FOLDER"],
            exist_ok=True
        )

        nome_foto = f"{uuid.uuid4().hex}.{extensao}"

        caminho = os.path.join(
            app.config["ALUNOS_UPLOAD_FOLDER"],
            nome_foto
        )

        foto.save(caminho)

    aluno = Aluno(
        nome=nome,
        turma=turma,
        foto=nome_foto
    )

    try:
        db.session.add(aluno)
        db.session.commit()

    except Exception:
        db.session.rollback()

        if nome_foto:
            caminho = os.path.join(
                app.config["ALUNOS_UPLOAD_FOLDER"],
                nome_foto
            )

            if os.path.exists(caminho):
                os.remove(caminho)

        flash("Erro ao cadastrar aluno.", "danger")
        return redirect(url_for("nossos_alunos"))

    flash("Aluno adicionado com sucesso!", "success")

    return redirect(url_for("nossos_alunos"))


# ============================================================
# VISUALIZAR E ATUALIZAR DADOS DO ALUNO
# ============================================================


@app.route("/nossos-alunos/<int:aluno_id>")
@login_required
def ver_dados_aluno(aluno_id):

    aluno = db.session.get(Aluno, aluno_id)

    if aluno is None:
        abort(404)

    arquivos_aluno = ArquivoAluno.query.filter_by(
        aluno_id=aluno.id
    ).order_by(
        ArquivoAluno.criado_em.desc()
    ).all()

    return render_template(
        "aluno_detalhes.html",
        aluno=aluno,
        arquivos=arquivos_aluno
    )


@app.route("/nossos-alunos/<int:aluno_id>/editar", methods=["GET", "POST"])
@login_required
def editar_aluno(aluno_id):

    aluno = db.session.get(Aluno, aluno_id)

    if aluno is None:
        abort(404)

    if request.method == "POST":

        if not token_valido():
            abort(400)

                # NOME DO ALUNO
        novo_nome = request.form.get("nome", "").strip()

        # TURMA DO ALUNO
        nova_turma = request.form.get("turma", "").strip()

        if not novo_nome or not nova_turma:
            flash(
                "O nome e a turma são obrigatórios.",
                "danger"
            )
            return redirect(
                url_for("editar_aluno", aluno_id=aluno.id)
            )

        aluno.nome = novo_nome
        aluno.turma = nova_turma

        # DATA DE NASCIMENTO
        aluno.data_nascimento = None

        nascimento = request.form.get(
            "data_nascimento", ""
        ).strip()

        if nascimento:
            try:
                aluno.data_nascimento = date.fromisoformat(
                    nascimento
                )
            except ValueError:
                flash("Data de nascimento inválida.", "danger")
                return redirect(
                    url_for("ver_dados_aluno", aluno_id=aluno.id)
                )

        # PRONTUÁRIO
        aluno.prontuario = request.form.get(
            "prontuario", ""
        ).strip() or None

        # IDENTIDADE (RG OU CPF)
        aluno.identidade = request.form.get(
            "identidade", ""
        ).strip() or None

        # EMAIL INSTITUCIONAL
        aluno.email_institucional = request.form.get(
            "email_institucional", ""
        ).strip() or None

        # CONTATO DOS RESPONSÁVEIS
        aluno.contato_responsaveis = request.form.get(
            "contato_responsaveis", ""
        ).strip() or None

        # VALIDAÇÃO DOS LIMITES DOS CAMPOS
        if (
            (aluno.prontuario and len(aluno.prontuario) > 30)
            or (aluno.identidade and len(aluno.identidade) > 30)
            or (aluno.email_institucional and len(aluno.email_institucional) > 120)
            or (aluno.contato_responsaveis and len(aluno.contato_responsaveis) > 255)
        ):
            flash(
                "Um dos dados informados ultrapassa o limite permitido.",
                "danger"
            )
            return redirect(
                url_for("ver_dados_aluno", aluno_id=aluno.id)
            )

        # DADOS ADICIONAIS
        aluno.dados_adicionais = request.form.get(
            "dados_adicionais", ""
        ).strip()

        # ARQUIVOS ENVIADOS
        arquivos = [
            arquivo
            for arquivo in request.files.getlist("arquivos")
            if arquivo and arquivo.filename
        ]

        extensoes_permitidas = {
            "pdf", "png", "jpg", "jpeg", "webp",
            "doc", "docx", "xls", "xlsx", "txt"
        }

        if len(arquivos) > 10:
            flash(
                "Você pode enviar até 10 arquivos por vez.",
                "danger"
            )
            return redirect(
                url_for("ver_dados_aluno", aluno_id=aluno.id)
            )

        # VALIDAR EXTENSÕES
        for arquivo in arquivos:

            nome_seguro = secure_filename(arquivo.filename)

            if not nome_seguro or "." not in nome_seguro:
                flash("Nome de arquivo inválido.", "danger")
                return redirect(
                    url_for("ver_dados_aluno", aluno_id=aluno.id)
                )

            extensao = nome_seguro.rsplit(".", 1)[-1].lower()

            if extensao not in extensoes_permitidas:
                flash(
                    "Um dos arquivos possui formato não permitido.",
                    "danger"
                )
                return redirect(
                    url_for("ver_dados_aluno", aluno_id=aluno.id)
                )

        # PASTA DE ARMAZENAMENTO
        pasta_arquivos = os.path.join(
            app.instance_path,
            "uploads",
            "alunos",
            "arquivos"
        )

        os.makedirs(pasta_arquivos, exist_ok=True)

        arquivos_salvos = []

        try:

            # SALVAR ARQUIVOS
            for arquivo in arquivos:

                nome_seguro = secure_filename(arquivo.filename)

                extensao = nome_seguro.rsplit(".", 1)[-1].lower()

                nome_unico = f"{uuid.uuid4().hex}.{extensao}"

                caminho = os.path.join(
                    pasta_arquivos,
                    nome_unico
                )

                arquivo.save(caminho)

                arquivos_salvos.append(caminho)

                registro = ArquivoAluno(
                    aluno_id=aluno.id,
                    nome_original=nome_seguro,
                    nome_arquivo=nome_unico
                )

                db.session.add(registro)

            # SALVAR ALTERAÇÕES NO BANCO
            db.session.commit()

        except Exception:

            db.session.rollback()

            for caminho in arquivos_salvos:
                if os.path.exists(caminho):
                    os.remove(caminho)

            flash(
                "Erro ao salvar os dados e arquivos.",
                "danger"
            )

            return redirect(
                url_for("ver_dados_aluno", aluno_id=aluno.id)
            )

        flash("Dados do aluno atualizados!", "success")

        return redirect(
            url_for("ver_dados_aluno", aluno_id=aluno.id)
        )

    # BUSCAR ARQUIVOS DO ALUNO
    arquivos_aluno = ArquivoAluno.query.filter_by(
        aluno_id=aluno.id
    ).order_by(
        ArquivoAluno.criado_em.desc()
    ).all()

    return render_template(
        "aluno_editar.html",
        aluno=aluno,
        arquivos=arquivos_aluno
    )


@app.route("/nossos-alunos/<int:aluno_id>/excluir", methods=["POST"])
@login_required
def excluir_aluno(aluno_id):

    if not token_valido():
        abort(400)

    aluno = db.session.get(Aluno, aluno_id)

    if aluno is None:
        abort(404)

    arquivos = ArquivoAluno.query.filter_by(
        aluno_id=aluno.id
    ).all()

    # Guardar os caminhos dos arquivos antes de excluir os registros
    caminhos = [
        os.path.join(
            app.instance_path,
            "uploads",
            "alunos",
            "arquivos",
            arquivo.nome_arquivo
        )
        for arquivo in arquivos
    ]

    caminho_foto = (
        os.path.join(
            app.config["ALUNOS_UPLOAD_FOLDER"],
            aluno.foto
        )
        if aluno.foto else None
    )

    try:
        for arquivo in arquivos:
            db.session.delete(arquivo)

        db.session.delete(aluno)
        db.session.commit()

    except Exception:
        db.session.rollback()
        flash("Erro ao excluir aluno.", "danger")
        return redirect(
            url_for("ver_dados_aluno", aluno_id=aluno.id)
        )

    # Apagar os arquivos físicos associados
    for caminho in caminhos:
        if os.path.exists(caminho):
            os.remove(caminho)

    if caminho_foto and os.path.exists(caminho_foto):
        os.remove(caminho_foto)

    flash("Aluno excluído com sucesso!", "success")

    return redirect(url_for("nossos_alunos"))


@app.route("/nossos-alunos/arquivo/<int:arquivo_id>")
@login_required
def abrir_arquivo_aluno(arquivo_id):

    arquivo = db.session.get(ArquivoAluno, arquivo_id)

    if arquivo is None:
        abort(404)

    pasta = os.path.join(
        app.instance_path,
        "uploads",
        "alunos",
        "arquivos"
    )

    return send_from_directory(
        pasta,
        arquivo.nome_arquivo,
        as_attachment=False,
        download_name=arquivo.nome_original
    )

# ============================================================
# LAUDOS (planilha do NAPNE)
# Só entra quem tem acesso especial: tipos ADM e NAPNE.
# ============================================================

TIPOS_ACESSO_ESPECIAL = ("ADM", "NAPNE")

TIPOS_DOCUMENTO = [
    "Laudo médico",
    "Exame",
    "Relatório",
    "Parecer",
    "PEI (Plano Educacional Individualizado)",
    "PAEE",
    "Estudo de Casos",
    "Receita / Prescrição",
    "Outro",
]

EXTENSOES_PERMITIDAS = {"pdf", "png", "jpg", "jpeg", "doc", "docx"}


def acesso_especial_required(f):
    """Exige login E tipo de usuário com acesso especial."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'usuario' not in session:
            return redirect(url_for('login'))

        if session.get("usuario_tipo") not in TIPOS_ACESSO_ESPECIAL:
            flash("Você não tem acesso à planilha de laudos.", "danger")
            return redirect(url_for('home'))

        return f(*args, **kwargs)

    return decorated_function


@app.context_processor
def variaveis_globais():
    # Usado no sidebar (mostrar o link "Laudos") e nos formulários (token CSRF)
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_hex(16)

    return {
        "tem_acesso_especial": session.get("usuario_tipo") in TIPOS_ACESSO_ESPECIAL,
        "csrf_token": session["csrf_token"],
    }


def token_valido():
    enviado = request.form.get("csrf_token", "")
    return secrets.compare_digest(enviado, session.get("csrf_token", ""))


def salvar_arquivo(arquivo):
    """Guarda o arquivo enviado. Devolve (nome_original, nome_salvo) ou None."""
    if not arquivo or not arquivo.filename:
        return None

    nome_original = secure_filename(arquivo.filename) or "arquivo"
    extensao = nome_original.rsplit(".", 1)[-1].lower() if "." in nome_original else ""

    if extensao not in EXTENSOES_PERMITIDAS:
        raise ValueError(
            "Tipo de arquivo não permitido. Use: "
            + ", ".join(sorted(EXTENSOES_PERMITIDAS)).upper() + "."
        )

    nome_salvo = f"{uuid.uuid4().hex}.{extensao}"
    arquivo.save(os.path.join(app.config["LAUDOS_FOLDER"], nome_salvo))
    return nome_original, nome_salvo


def apagar_arquivo(nome_salvo):
    if nome_salvo:
        caminho = os.path.join(app.config["LAUDOS_FOLDER"], nome_salvo)
        if os.path.exists(caminho):
            os.remove(caminho)


def preencher_laudo(laudo):
    """Copia os campos do formulário para o objeto Laudo. Devolve mensagem de erro ou None."""
    f = request.form

    laudo.aluno_nome = f.get("aluno_nome", "").strip()
    laudo.aluno_prontuario = f.get("aluno_prontuario", "").strip()
    laudo.curso_turma = f.get("curso_turma", "").strip() or None
    laudo.tipo_documento = f.get("tipo_documento", "").strip()
    laudo.condicao = f.get("condicao", "").strip() or None
    laudo.profissional = f.get("profissional", "").strip() or None
    laudo.observacoes = f.get("observacoes", "").strip() or None

    data_texto = f.get("data_documento", "").strip()
    try:
        laudo.data_documento = datetime.strptime(data_texto, "%Y-%m-%d").date() if data_texto else None
    except ValueError:
        return "Data de emissão do laudo inválida."

    if not laudo.aluno_nome:
        return "Preencha o nome do aluno."
    if not laudo.aluno_prontuario:
        return "Preencha o prontuário do aluno."
    if not laudo.curso_turma:
        return "Preencha o curso / turma."
    if not laudo.tipo_documento:
        return "Selecione o tipo de documento."
    if laudo.tipo_documento not in TIPOS_DOCUMENTO:
        return "Tipo de documento inválido."
    if not laudo.profissional:
        return "Preencha o nome do médico / instituição."
    if not laudo.data_documento:
        return "Preencha a data de emissão do laudo."
    if laudo.data_documento > datetime.now().date():
        return "A data de emissão do laudo não pode ser no futuro."

    return None


@app.route("/laudos")
@acesso_especial_required
def laudos():
    busca = request.args.get("q", "").strip()
    tipo = request.args.get("tipo", "").strip()

    consulta = Laudo.query

    if busca:
        termo = f"%{busca}%"
        consulta = consulta.filter(or_(
            Laudo.aluno_nome.ilike(termo),
            Laudo.aluno_prontuario.ilike(termo),
            Laudo.curso_turma.ilike(termo),
            Laudo.condicao.ilike(termo),
            Laudo.profissional.ilike(termo),
        ))

    if tipo:
        consulta = consulta.filter(Laudo.tipo_documento == tipo)

    registros = consulta.order_by(Laudo.aluno_nome, Laudo.data_documento.desc()).all()

    return render_template(
        "laudos.html",
        registros=registros,
        tipos=TIPOS_DOCUMENTO,
        busca=busca,
        tipo_filtro=tipo,
        hoje=datetime.now().date().isoformat(),
    )


@app.route("/laudos/novo", methods=["POST"])
@acesso_especial_required
def laudo_novo():
    if not token_valido():
        abort(400)

    laudo = Laudo(criado_por=session.get("nome_usuario"))
    erro = preencher_laudo(laudo)

    if not erro:
        try:
            salvo = salvar_arquivo(request.files.get("arquivo"))
            if salvo:
                laudo.arquivo_nome, laudo.arquivo_salvo = salvo
        except ValueError as e:
            erro = str(e)

    if erro:
        flash(erro, "danger")
        return redirect(url_for("laudos"))

    db.session.add(laudo)
    db.session.commit()
    flash("Registro adicionado à planilha.", "success")
    return redirect(url_for("laudos"))


@app.route("/laudos/<int:laudo_id>/editar", methods=["POST"])
@acesso_especial_required
def laudo_editar(laudo_id):
    if not token_valido():
        abort(400)

    laudo = db.get_or_404(Laudo, laudo_id)
    erro = preencher_laudo(laudo)
    arquivo_antigo = None

    if not erro:
        try:
            salvo = salvar_arquivo(request.files.get("arquivo"))
            if salvo:
                arquivo_antigo = laudo.arquivo_salvo
                laudo.arquivo_nome, laudo.arquivo_salvo = salvo
        except ValueError as e:
            erro = str(e)

    if erro:
        db.session.rollback()
        flash(erro, "danger")
        return redirect(url_for("laudos"))

    db.session.commit()
    apagar_arquivo(arquivo_antigo)  # só apaga o antigo depois de salvar com sucesso
    flash("Registro atualizado.", "success")
    return redirect(url_for("laudos"))


@app.route("/laudos/<int:laudo_id>/excluir", methods=["POST"])
@acesso_especial_required
def laudo_excluir(laudo_id):
    if not token_valido():
        abort(400)

    laudo = db.get_or_404(Laudo, laudo_id)
    arquivo = laudo.arquivo_salvo

    db.session.delete(laudo)
    db.session.commit()
    apagar_arquivo(arquivo)

    flash("Registro excluído.", "success")
    return redirect(url_for("laudos"))


@app.route("/laudos/<int:laudo_id>/arquivo")
@acesso_especial_required
def laudo_arquivo(laudo_id):
    laudo = db.get_or_404(Laudo, laudo_id)

    if not laudo.arquivo_salvo:
        abort(404)

    return send_from_directory(
        app.config["LAUDOS_FOLDER"],
        laudo.arquivo_salvo,
        download_name=laudo.arquivo_nome,
    )


@app.errorhandler(RequestEntityTooLarge)
def arquivo_grande_demais(e):
    flash("Arquivo muito grande. O limite é 16 MB.", "danger")
    return redirect(url_for("laudos"))